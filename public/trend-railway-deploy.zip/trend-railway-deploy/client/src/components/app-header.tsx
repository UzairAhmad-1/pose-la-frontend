import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { Button } from "@/components/ui/button";
import { useEffect, useMemo } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LanguageSelectorButton } from "@/components/language-selector";
import ShareApp from "@/components/share-app";
import { NotificationBell } from "@/components/notification-bell";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  LogOut,
  User,
  Trophy,
  Shield,
  Menu,
  BarChart3,
  Search,
  ChevronDown,
  Home,
} from "lucide-react";
import { Link, useLocation } from "wouter";

export default function AppHeader() {
  const { user, logoutMutation } = useAuth();
  const { t } = useLanguage();
  const [location] = useLocation();

  // Compute title dynamically based on current route
  const pageTitle = useMemo(() => {
    if (location.startsWith("/profile")) return "Profile";
    if (location.startsWith("/leaderboard")) return "Leaderboard";
    if (location.startsWith("/admin")) return "Admin Panel";
    if (location.startsWith("/assets/")) return "Asset Detail";
    if (location.startsWith("/chart")) return "Trading Chart";
    if (location.startsWith("/predict")) return "Make Prediction";
    if (location.startsWith("/auth")) return "Login / Register";
    if (location.startsWith("/user/")) return "User Profile";
    return "Dashboard";
  }, [location]);

  const handleLogout = () => logoutMutation.mutate();

  return (
    <header className="bg-[#2f343a] sticky top-0 z-50">
      <div className="container max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Left: Dynamic Title */}
        <div className="flex items-center space-x-4 min-w-0">
          <Link href="/" className="flex items-center">
            <span
              className="text-white font-semibold text-2xl leading-none"
              style={{ fontFamily: "Poppins, sans-serif" }}
            >
              {pageTitle}
            </span>
          </Link>
        </div>

        {/* Center: Search */}
        <div className="flex-1 px-6 hidden sm:flex items-center justify-center">
          <div className="w-full max-w-md">
            <div className="relative">
              <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </span>
              <input
                type="text"
                placeholder="Search.."
                className="w-full bg-[#23272b] text-neutral-200 placeholder:text-neutral-500 rounded-full h-10 pl-10 pr-4 border border-transparent focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>
          </div>
        </div>

        {/* Right: Controls */}
        <div className="flex items-center space-x-3">
          {/* Small search on mobile */}
          <div className="sm:hidden">
            <button className="h-9 w-9 rounded-full flex items-center justify-center bg-[#23272b] border border-transparent">
              <Search className="h-4 w-4 text-neutral-300" />
            </button>
          </div>

          <LanguageSelectorButton />
          {user && <NotificationBell />}

          {/* Avatar + Dropdown */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center space-x-3 bg-transparent rounded-md px-2 py-1 hover:bg-[#2f3438]">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {user.username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden sm:flex flex-col items-start leading-tight min-w-[120px]">
                    <span className="text-sm font-medium text-neutral-100">
                      {user.username}
                    </span>
                    <span className="text-xs text-neutral-400">
                      {user.email}
                    </span>
                  </div>
                  <ChevronDown className="h-4 w-4 text-neutral-300" />
                </button>
              </DropdownMenuTrigger>

              <DropdownMenuContent className="w-56" align="end">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {user.username}
                    </p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="flex w-full">
                    <User className="mr-2 h-4 w-4" />
                    <span>{t("nav.profile")}</span>
                  </Link>
                </DropdownMenuItem>

                {user?.role === "admin" && (
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="flex w-full">
                      <Shield className="mr-2 h-4 w-4" />
                      <span>{t("admin.dashboard")}</span>
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{t("nav.logout")}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex space-x-2">
              <Button variant="outline" asChild>
                <Link href="/auth">{t("nav.login")}</Link>
              </Button>
              <Button asChild>
                <Link href="/auth?mode=register">{t("nav.register")}</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
