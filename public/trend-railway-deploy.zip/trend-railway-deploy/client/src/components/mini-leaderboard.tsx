import { useQuery } from "@tanstack/react-query";
import { API_ENDPOINTS } from "@/lib/api-config";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, Crown } from "lucide-react";

type MiniLeaderboardResponse = {
  topThree: Array<{ userId: string; username: string; points: number; totalPredictions: number; correctPredictions: number }>;
  stockKing: { userId: string; username: string; points: number } | null;
  cryptoKing: { userId: string; username: string; points: number } | null;
};

function RankMedal({ rank }: { rank: number }) {
  const colors = {
    1: "text-yellow-500",
    2: "text-gray-400",
    3: "text-amber-700",
  } as const;
  const emojis = { 1: "🥇", 2: "🥈", 3: "🥉" } as const;
  return <span className={`text-lg ${colors[rank as 1 | 2 | 3]}`}>{emojis[rank as 1 | 2 | 3]}</span>;
}

export default function MiniLeaderboard() {
  const { data } = useQuery<MiniLeaderboardResponse>({
    queryKey: [API_ENDPOINTS.LEADERBOARD_MINI()],
  });

  const topThree = data?.topThree || [];
  const stockKing = data?.stockKing || null;
  const cryptoKing = data?.cryptoKing || null;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2"><Trophy className="h-4 w-4" />Top 3 All Time</CardTitle>
        <CardDescription>Total points across all evaluated predictions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {topThree.length === 0 ? (
            <div className="text-sm text-muted-foreground">No data yet</div>
          ) : (
            topThree.map((u, i) => (
              <div key={u.userId} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <RankMedal rank={i + 1} />
                  <Avatar className="h-6 w-6">
                    <AvatarFallback>{(u.username || "?").slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{u.username}</span>
                </div>
                <div className="text-sm tabular-nums font-mono">{u.points}</div>
              </div>
            ))
          )}
        </div>

        <div className="pt-2 border-t" />

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Crown className="h-4 w-4 text-blue-600" />
              <span className="font-medium">Stock King</span>
            </div>
            {stockKing ? (
              <div className="flex items-center gap-2">
                <span className="text-sm">{stockKing.username}</span>
                <span className="text-sm tabular-nums font-mono">{stockKing.points}</span>
              </div>
            ) : (
              <span className="text-sm text-muted-foreground">—</span>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Crown className="h-4 w-4 text-emerald-600" />
              <span className="font-medium">Crypto King</span>
            </div>
            {cryptoKing ? (
              <div className="flex items-center gap-2">
                <span className="text-sm">{cryptoKing.username}</span>
                <span className="text-sm tabular-nums font-mono">{cryptoKing.points}</span>
              </div>
            ) : (
              <span className="text-sm text-muted-foreground">—</span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}


