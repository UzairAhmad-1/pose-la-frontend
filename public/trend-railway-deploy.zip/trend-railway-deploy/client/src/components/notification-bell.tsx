import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { NotificationList } from "./notification-list";
import { API_BASE_URL } from "@/lib/api-config";
import { authenticatedFetch } from "@/lib/auth-helpers";

interface UnreadCountResponse {
  count: number;
}

export function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false);
  const queryClient = useQueryClient();

  // Fetch unread notification count
  const { data: unreadData } = useQuery<UnreadCountResponse>({
    queryKey: ["/api/notifications/unread/count"],
    queryFn: async () => {
      console.log('🔔 Fetching unread count from:', `${API_BASE_URL}/api/notifications/unread/count`);
      const response = await authenticatedFetch(`${API_BASE_URL}/api/notifications/unread/count`);
      
      if (!response.ok) {
        console.error('❌ Failed to fetch unread count:', response.status, response.statusText);
        throw new Error('Failed to fetch unread count');
      }
      
      const data = await response.json();
      console.log('📊 Unread count response:', data);
      return data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const unreadCount = unreadData?.count || 0;

  // Mark all as read mutation
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const response = await authenticatedFetch(`${API_BASE_URL}/api/notifications/read-all`, {
        method: 'PATCH',
      });
      
      if (!response.ok) {
        throw new Error('Failed to mark all notifications as read');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread/count"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open);
    
    // Don't automatically mark as read - let user see the notifications first
    // They can mark as read manually or by clicking on notifications
  };

  return (
    <Popover open={isOpen} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 h-5 min-w-5 flex items-center justify-center p-0 text-xs"
              variant="destructive"
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <NotificationList />
      </PopoverContent>
    </Popover>
  );
}

