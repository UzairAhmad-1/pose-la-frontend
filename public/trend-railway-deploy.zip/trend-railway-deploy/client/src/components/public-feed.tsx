import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { API_BASE_URL, API_ENDPOINTS } from "@/lib/api-config";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Award, CheckCircle2, XCircle } from "lucide-react";

type FeedEvent = {
  type: "prediction_created" | "prediction_closed" | "badge_earned";
  createdAt: string;
  id: string;
  username: string | null;
  assetSymbol: string | null;
  direction: "up" | "down" | null;
  result: "correct" | "incorrect" | null;
  pointsAwarded: number | null;
  badgeType: string | null;
};

export default function PublicFeed() {
  const { data } = useQuery<{ events: FeedEvent[] }>({
    queryKey: [API_ENDPOINTS.FEED_PUBLIC()],
  });

  const [events, setEvents] = useState<FeedEvent[]>([]);
  useEffect(() => {
    if (data?.events) {
      setEvents(data.events);
    }
  }, [data]);

  // Realtime via WebSocket (anonymous allowed)
  const wsRef = useRef<WebSocket | null>(null);
  useEffect(() => {
    const computeWsUrl = () => {
      if (API_BASE_URL) {
        try {
          const u = new URL(API_BASE_URL);
          const wsProto = u.protocol === "https:" ? "wss:" : "ws:";
          return `${wsProto}//${u.host}`;
        } catch {}
      }
      const host = window.location.hostname || "localhost";
      const wsProto = window.location.protocol === "https:" ? "wss:" : "ws:";
      return `${wsProto}//${host}:3002`;
    };
    const wsUrl = computeWsUrl();
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg?.type === "feed_event" && msg.event) {
          setEvents((prev) => {
            const e = msg.event as FeedEvent;
            // de-duplicate by type+id
            const key = `${e.type}-${e.id}`;
            const seen = new Set(prev.map((p) => `${p.type}-${p.id}`));
            if (seen.has(key)) return prev;
            const next = [e, ...prev];
            return next.slice(0, 10);
          });
        }
      } catch {
        // ignore non-JSON control frames
      }
    };
    return () => {
      ws.close(1000);
    };
  }, []);

  const renderList = (items: FeedEvent[]) =>
    items.length === 0 ? (
      <div className="text-sm text-muted-foreground">No activity yet</div>
    ) : (
      <ul className="space-y-2">
        {items.map((e) => {
          const when = new Date(e.createdAt).toLocaleString();
          const icon =
            e.type === "prediction_created" ? (
              <TrendingUp className="h-4 w-4 text-blue-600" />
            ) : e.type === "prediction_closed" ? (
              e.result === "correct" ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )
            ) : (
              <Award className="h-4 w-4 text-amber-600" />
            );

          const text =
            e.type === "prediction_created" ? (
              <span>
                <b>{e.username}</b> predicted{" "}
                <b>{e.direction?.toUpperCase()}</b> on <b>{e.assetSymbol}</b>
              </span>
            ) : e.type === "prediction_closed" ? (
              <span>
                <b>{e.username}</b>'s prediction on <b>{e.assetSymbol}</b>{" "}
                closed: <b>{e.result?.toUpperCase()}</b>
                {typeof e.pointsAwarded === "number"
                  ? ` (${e.pointsAwarded > 0 ? "+" : ""}${e.pointsAwarded})`
                  : ""}
              </span>
            ) : (
              <span>
                <b>{e.username}</b> earned a badge
              </span>
            );

          const chip =
            e.type === "badge_earned" && e.badgeType ? (
              <Badge variant="secondary" className="text-xs whitespace-nowrap">
                {e.badgeType}
              </Badge>
            ) : null;

          return (
            <li
              key={`${e.type}-${e.id}`}
              className="flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3 min-w-0">
                {icon}
                <div className="text-sm truncate">{text}</div>
              </div>
              <div className="flex items-center gap-3">
                {chip}
                <div className="text-xs text-muted-foreground w-40 text-right whitespace-nowrap">
                  {when}
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    );

  const onlyPredictions = events.filter(
    (e) => e.type === "prediction_created" || e.type === "prediction_closed"
  );
  const onlyBadges = events.filter((e) => e.type === "badge_earned");

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-4 grid grid-cols-4 w-full">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="network">Followers / Following</TabsTrigger>
          </TabsList>

          <TabsContent value="all">{renderList(events)}</TabsContent>
          <TabsContent value="predictions">
            {renderList(onlyPredictions)}
          </TabsContent>
          <TabsContent value="achievements">
            {renderList(onlyBadges)}
          </TabsContent>
          <TabsContent value="network">
            <div className="text-sm text-muted-foreground">
              Network activity coming soon
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
