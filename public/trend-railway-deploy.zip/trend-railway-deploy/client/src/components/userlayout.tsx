import React, { useState } from "react";
import Sidebar from "./usersidebar";
import AppHeader from "./app-header";
import { Menu, X, Search } from "lucide-react";

interface UserLayoutProps {
  children: React.ReactNode;
}

const UserLayout: React.FC<UserLayoutProps> = ({ children }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-[#111318] text-white overflow-hidden">
      {/* Sidebar for desktop */}
      <div className="hidden md:block">
        <Sidebar />
      </div>

      {/* Sidebar for mobile (overlay) */}
      <div
        className={`fixed inset-0 z-50 bg-black/50 backdrop-blur-sm transition-opacity md:hidden ${
          mobileMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
        onClick={() => setMobileMenuOpen(false)}
      >
        <div
          className="absolute left-0 top-0 h-full w-64 bg-[#1C1F26] shadow-lg p-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-xl font-bold">Trend</h1>
            <button onClick={() => setMobileMenuOpen(false)}>
              <X className="h-6 w-6 text-gray-300" />
            </button>
          </div>
          <Sidebar />
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden bg-[#1E2026]">
        {/* Mobile Header */}
        <div className="md:hidden flex justify-between items-center p-4 bg-[#1E2026] border-b border-[#2B2E34]">
          <div className="flex items-center gap-2">
            <button onClick={() => setMobileMenuOpen(true)}>
              <Menu className="h-6 w-6 text-gray-300" />
            </button>
            <h1 className="font-bold text-lg">Trend</h1>
          </div>

          <div className="flex items-center gap-3">
            <button className="p-2 bg-[#2B2E34] rounded-lg hover:bg-[#35383F] transition">
              <Search className="h-5 w-5 text-gray-300" />
            </button>
            <div className="w-8 h-8 rounded-full bg-gray-500"></div>
          </div>
        </div>

        {/* Desktop Header */}
        <div className="hidden md:block">
          <AppHeader />
        </div>

        {/* Body */}
        <main className="flex-1 overflow-y-auto px-6 py-6 md:px-8 md:py-8 bg-[#2f343a]">
          {children}
        </main>
      </div>
    </div>
  );
};

export default UserLayout;
