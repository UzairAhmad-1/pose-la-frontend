import React from "react";
import { LayoutGrid, LineChart, Trophy, User, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";

const Sidebar: React.FC = () => {
  const [location] = useLocation();

  return (
    <aside className="h-screen w-[90px] md:w-[240px] bg-[#1E1F25] text-gray-300 flex flex-col justify-between py-6">
      {/* Top section */}
      <div>
        {/* Logo */}
        <div className="flex items-center gap-2 px-6 mb-8">
          <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-blue-400 rounded-full" />
          <h1 className="hidden md:block text-white font-semibold text-lg">
            Trend
          </h1>
        </div>

        {/* Navigation */}
        <nav className="flex flex-col gap-1">
          {/* Overview - active */}
          <Link href="/" className="block">
            <button
              className={`flex items-center gap-3 w-full px-6 py-3 rounded-xl font-medium transition ${
                location === "/"
                  ? "bg-blue-600 text-white"
                  : "hover:bg-[#2A2B32] text-gray-300"
              }`}
            >
              <LayoutGrid size={18} />
              <span className="hidden md:inline">Overview</span>
            </button>
          </Link>

          {/* Chart */}
          <Link href="/chart" className="block">
            <button
              className={`flex items-center gap-3 w-full px-6 py-3 rounded-xl font-medium transition ${
                location === "/chart"
                  ? "bg-blue-600 text-white"
                  : "hover:bg-[#2A2B32] text-gray-300"
              }`}
            >
              <LineChart size={18} />
              <span className="hidden md:inline">Chart</span>
            </button>
          </Link>

          {/* Leaderboard */}
          <Link href="/leaderboard" className="block">
            <button
              className={`flex items-center gap-3 w-full px-6 py-3 rounded-xl font-medium transition ${
                location === "/leaderboard"
                  ? "bg-blue-600 text-white"
                  : "hover:bg-[#2A2B32] text-gray-300"
              }`}
            >
              <Trophy size={18} />
              <span className="hidden md:inline">Leaderboard</span>
            </button>
          </Link>
        </nav>
      </div>

      {/* Bottom section */}
      <div className="flex flex-col gap-2 px-6">
        <Link href="/profile" className="block">
          <button
            className={`flex items-center gap-3 w-full py-3 rounded-xl font-medium transition ${
              location === "/profile"
                ? "bg-blue-600 text-white"
                : "hover:bg-[#2A2B32] text-gray-300"
            }`}
          >
            <User size={18} />
            <span className="hidden md:inline">Profile</span>
          </button>
        </Link>

        <button className="flex items-center gap-3 w-full py-3 rounded-xl hover:bg-[#2A2B32] transition text-gray-400">
          <LogOut size={18} />
          <span className="hidden md:inline">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
