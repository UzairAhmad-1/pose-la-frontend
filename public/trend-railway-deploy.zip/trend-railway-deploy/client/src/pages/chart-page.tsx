"use client";

import React from "react";
import { useRoute } from "wouter";
import AppHeader from "@/components/app-header";
import TradingViewChart from "@/components/tradingview-chart";
import { Button } from "@/components/ui/button";
import { Maximize2, Minimize2, Search } from "lucide-react";
import { Link } from "wouter";

export default function ChartPage() {
  const [, params] = useRoute("/chart/:symbol?");
  const symbol = params?.symbol
    ? decodeURIComponent(params.symbol)
    : "NASDAQ:AAPL";
  const [isFullscreen, setIsFullscreen] = React.useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#2f343a] text-white">
      <main className="container max-w-6xl mx-auto px-4 py-2 space-y-6">
        {/* Advanced Chart Box */}
        <div className="">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold">Analytics Price Target</h2>
            </div>

            <Button
              variant="outline"
              onClick={toggleFullscreen}
              className="flex items-center space-x-2 border-gray-600 text-gray-300 hover:bg-[#2C2F36]"
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="h-4 w-4" />
                  <span>Exit Fullscreen</span>
                </>
              ) : (
                <>
                  <Maximize2 className="h-4 w-4" />
                  <span>Fullscreen</span>
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Analytics / Chart Box */}

        {/* Chart */}
        <div className="">
          <TradingViewChart defaultSymbol={symbol} height={500} />
        </div>

        {/* Chart Features Info (unchanged) */}
      </main>
    </div>
  );
}
