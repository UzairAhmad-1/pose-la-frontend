import React, { useState } from "react";
import { buildApiUrl } from "@/lib/api-config";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import AppHeader from "@/components/app-header";
import { EnhancedPredictionForm } from "@/components/enhanced-prediction-form";
import AnalystConsensusCard from "@/components/analyst-consensus-card";
import { DollarSign, TrendingUp, TrendingDown } from "lucide-react";

import { API_ENDPOINTS } from "@/lib/api-config";
export default function PredictionPage() {
  const [, params] = useRoute("/predict/:assetSymbol");
  const assetSymbol = params?.assetSymbol;

  const { data: asset, isLoading: isLoadingAsset } = useQuery({
    queryKey: ["asset", assetSymbol],
    queryFn: async () => {
      const response = await fetch(buildApiUrl(`/api/assets/${assetSymbol}`));
      if (!response.ok) throw new Error("Failed to fetch asset");
      return response.json();
    },
    enabled: !!assetSymbol,
  });

  // Fetch price ONCE on page load - NO continuous refresh
  const { data: priceData, isLoading: isLoadingPrice } = useQuery<{
    price: number;
    change24h?: number;
  }>({
    queryKey: [`prediction-price-${assetSymbol}`],
    queryFn: async () => {
      console.log(
        "[PRICE FETCH] Prediction page load - fetching price for:",
        assetSymbol
      );

      const response = await fetch(
        `/api/catalog/price/${encodeURIComponent(assetSymbol || "")}`
      );

      if (!response.ok) {
        console.log("[PRICE FETCH] Failed for:", assetSymbol);
        throw new Error("Failed to fetch price");
      }

      const data = await response.json();
      console.log(
        "[PRICE FETCH] Success for:",
        assetSymbol,
        "Price:",
        data.price,
        "API calls:",
        data.priceCallsMade
      );

      return {
        price: data.price,
        change24h: data.change24h,
      };
    },
    enabled: !!assetSymbol,
    staleTime: Infinity, // NEVER auto-refresh
    gcTime: Infinity, // Keep in cache
    retry: 2,
  });

  if (isLoadingAsset) {
    return (
      <div className="min-h-screen bg-background">
        <main className="container max-w-6xl mx-auto px-4 py-6">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3"></div>
            <div className="h-64 bg-muted rounded"></div>
          </div>
        </main>
      </div>
    );
  }

  if (!asset) {
    return (
      <div className="min-h-screen bg-background">
        <main className="container max-w-6xl mx-auto px-4 py-6">
          <Card className="border-red-500/20 bg-red-500/10">
            <CardContent className="pt-6">
              <p className="text-red-400 text-center">Asset not found</p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#2f343a]">
      <main className="container max-w-6xl mx-auto px-4 py-6">
        {/* Asset Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-muted-foreground">
                Predict the price movement for {asset.symbol} using our enhanced
                slot system
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">{asset.type}</Badge>
              <Badge variant={asset.isActive ? "default" : "secondary"}>
                {asset.isActive ? "Active" : "Inactive"}
              </Badge>
            </div>
          </div>
        </div>

        {/* Current Price Display */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Current Price
            </CardTitle>
            <CardDescription>
              Price loaded once - a fresh price will be fetched when you submit
              your prediction
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingPrice ? (
              <Skeleton className="h-12 w-32" />
            ) : priceData ? (
              <div className="space-y-2">
                <div className="text-3xl font-bold">
                  ${priceData.price.toFixed(2)}
                </div>
                {priceData.change24h !== undefined && (
                  <div
                    className={`flex items-center gap-1 text-sm ${
                      priceData.change24h >= 0
                        ? "text-green-600"
                        : "text-red-600"
                    }`}
                  >
                    {priceData.change24h >= 0 ? (
                      <TrendingUp className="h-4 w-4" />
                    ) : (
                      <TrendingDown className="h-4 w-4" />
                    )}
                    <span>
                      {priceData.change24h >= 0 ? "+" : ""}
                      {priceData.change24h.toFixed(2)}% (24h)
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-muted-foreground">Price unavailable</div>
            )}
          </CardContent>
        </Card>

        {/* Analyst Consensus */}
        <div className="mb-8">
          <AnalystConsensusCard assetSymbol={assetSymbol || ""} />
        </div>

        {/* Prediction Form */}
        <EnhancedPredictionForm
          assetSymbol={asset.symbol}
          onSuccess={() => {
            // Refresh data after successful prediction
            window.location.reload();
          }}
        />
      </main>
    </div>
  );
}
